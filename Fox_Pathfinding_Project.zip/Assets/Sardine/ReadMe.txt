Thank you for downlording.

-Models folder contains fbx files of sardine's meshes.
-Animatiions folder contains animation's fbx files.
You can use these animation in all of sardine models(SardineBoneModel.fbx, SardineSkinAndBoneModel.fbx, SardineSkinModel.fbx, 
SimpleSardine.fbx).
-Scenes folder contains two demo scenes.
-Prefabs folder contains prefabs.
SardineSkinWithDemoScript is used in Demo1.0
SardineSkinWithController is used in Demo1.2.1

support@ryousirikigaku.com